package com.example.one;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import static java.lang.Integer.parseInt;


public class MainActivity extends  AppCompatActivity{




    public void view1 ( View view , Bundle savedInstanceState ) {











    }



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );

    }





    public static class YourPreference {

        private static YourPreference yourPreference;
        private SharedPreferences sharedPreferences;

        public static YourPreference getInstance ( Context context ) {
            if ( yourPreference == null ) {
                yourPreference = new YourPreference ( context );
            }
            return yourPreference;
        }

        private YourPreference ( Context context ) {
            sharedPreferences = context.getSharedPreferences ( "YourCustomNamedPreference" , Context.MODE_PRIVATE );
        }

        public void saveData ( String key , String value ) {
            SharedPreferences.Editor prefsEditor = sharedPreferences.edit ( );
            prefsEditor.putString ( key , value );
            prefsEditor.commit ( );
        }

        public String getData ( String key ) {
            if ( sharedPreferences != null ) {
                return sharedPreferences.getString ( key , "" );
            }
            return "";





        }}}



